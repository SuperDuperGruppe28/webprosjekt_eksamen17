<?php
        if(isset($_GET['tag']))
        {
            $id = $_GET['tag'];
        }
?>

<h3>Café</h3>

<div id="katogorier">
    <a href="?side=restauranter"><p>Restauranter</p></a>
    <a href="?side=cafe"><p>Café</p></a>
    <a href="?side=pub"><p>Pub</p></a>
    <a href="?side=natur"><p>Natur</p></a>
    <a href="?side=sport"><p>Sport</p></a>
</div>

<div id="topleft">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 
    <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
                <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>

<div id="topcenter">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 

        <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
             <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>

<div id="topright">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 

        <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
             <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>

<div id="bottomleft">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 

        <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
             <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>

<div id="bottomcenter">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 
        <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
             <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>

<div id="bottomright">
    <img id="vannbilde" src="/img/COLOURBOX2340325.jpg" alt="Vann"> 
        <div id="textbox">
           <div>
               <p>POKALEN RESTAURANT</p>
             <span >Kun det beste innen sport på fjernsyn, musikk og godt drikke. Pokalen viser det aller meste av kamper fra Premier League, Champions league, utvalgte godbiter NFL, hockey, skiskytning, hopprenn, Sundby vs Northug og annen idrett. 10 skjermer som hengyer høyt nok til at alle ser, tre soner, bra lyd, digge sofaer og et herlig utvalg av godt drikke. Både flaske og tapp.</span ></br>
           </div>  
    </div>
</div>