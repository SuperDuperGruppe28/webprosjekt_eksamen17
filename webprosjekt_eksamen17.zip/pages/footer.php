<div id="footerContainer">
    <center>SuperDuperGruppe28(c) 2017</center>
</div>